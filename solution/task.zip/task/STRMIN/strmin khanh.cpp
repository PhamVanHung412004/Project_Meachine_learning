#include<bits/stdc++.h>
using namespace std;

int n, x, y, z;

int main()
{
	if(fopen("strmin.inp","r"))
	{
		freopen("strmin.inp","r",stdin);
		freopen("strmin.out","w",stdout);
	}
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
	cout.tie(nullptr);
	
	cin >> n >> x >> y >> z;
	
	string res = "";
	for(int i = 1; i <= max(z, n - x - y); i++)
	{
		if(i % 2 == 1) res += '0';
		else res += '1';
	}
	
	for(int i = 1; i <= x; i++)
	{
		if(i % 2 == 1) res += 'A';
		else res += 'B'; 
	}

	for(int i = 1; i <= y; i++)
	{
		if(i % 2 == 1) res += 'a';
		else res += 'b';
	}
	
	cout << res;
}
