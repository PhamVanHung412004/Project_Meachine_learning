#include<bits/stdc++.h>
#define task "STRMIN"

using namespace std;

int n,x,y,z;

int main(){
    if(fopen(task".inp","r")){
        freopen(task".inp","r",stdin);
        freopen(task".out","w",stdout);
    }
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cin >> n >> x >> y >> z;
    for(int i = 1;i <= max(n - x - y,z);++ i){
        if(i % 2 == 1) cout << "0";
        else cout << "1";
    }
    for(int i = 1;i <= x;++ i){
        if(i % 2 == 1) cout << "A";
        else cout << "B";
    }
    for(int i = 1;i <= y;++ i){
        if(i % 2 == 1) cout << "a";
        else cout << "b";
    }
}


