#include <bits/stdc++.h>
using namespace std;
int n,x,y,z;
string s,a,b,c;
int main(){
    freopen("strmin.inp","r",stdin);
    freopen("strmin.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    cin>>n>>x>>y>>z;
    for(int i=0;i<z;i++){
        if(i%2==0) a+='0';
        else a+='1';
    }
    for(int i=0;i<y;i++){
        if(i%2==0) b+='a';
        else b+='b';
    }
    for(int i=0;i<x;i++){
        if(i%2==0) c+='A';
        else c+='B';
    }
    if(n>x+y+z) {
        n-=x+y+z;
        if(z!=0) for(int i=z;i<z+n;i++){
                    if(i%2==0) a+='0';
                    else a+='1';
                }
        else if(x!=0) for(int i=x;i<x+n;i++){
                    if(i%2==0) c+='A';
                    else c+='B';
                }
        else for(int i=y;i<y+n;i++){
                    if(i%2==0) b+='a';
                    else b+='b';
            }
    }
    s=a+c+b;
    cout<<s;
    return 0;
}

