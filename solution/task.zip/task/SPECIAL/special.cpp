#include<bits/stdc++.h>
#define ll long long
using namespace std;
int l,r;
long long ans,c[3000004];
void sub1()
{
    for (int x=l; x<=r; x++)
    {
        long long s=0;
        for (int i=1; i<x; i++)
            if(x%i==0) s+=i;
        if (s>x) ans+=1;
    }
    cout<<ans;
}
void sub2()
{
    for (int x=l; x<=r; x++)
    {
        long long s=1;
        for (int i=2; i*i<=x; i++)
            if(x%i==0) {
                    s+=i+x/i;
                    if (i*i==x) s-=i;}
        if (s>x) ans+=1;
    }
    cout<<ans;
}
void tonguoc(int r)
{
    for(int i=1; i<=r+1; i++) c[i]=1;
    for (ll i=2; i*i<=r; i++)
        for (ll j=i*i; j<=r; j+=i)
        {
            c[j]+=i;
            if (i*i!=j) c[j]+=j/i;
        }
}
void sub3()
{
    ans=0; tonguoc(r);
    for (ll x=l; x<=r; x++)
        if (c[x]>x) ans+=1;
    cout<<ans;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
     if (fopen("special.inp", "r")) {
        freopen("special.inp", "r", stdin);
        freopen("special.out", "w", stdout);
    }
    cin>>l>>r;
    if (l<=1000 && r<=1000) sub1();
    else if (l<=100000 && r<=100000)  sub2();
             else sub3();
}
