#include <bits/stdc++.h>

using namespace std;

const int maxn= 1e5 + 5;
const int maxm= 2e5 + 5;

int n, Q, a[maxn], q[maxn];
int tmp[maxm], m;
int Pre[maxn], Next[maxn];
int x[maxm], s[maxm];

void sub1 ()
{
    for (int i=1; i<=Q; ++i) {
        int nho= 1, ans= 0;
        for (int j=1; j<=n; ++j) {
            if (a[j] <= q[i]) {
                ans= max (ans, j - nho + 1);
            }
            else nho= j+1;
        }

        printf ("%d\n", ans);
    }
}

void sub2 ()
{
    a[0]= m + 1;
    for (int i=1; i<=n; ++i) {
        int j= i - 1;
        while (a[j] <= a[i]) j= Pre[j];

        Pre[i]= j;// vị trí của phần tử xa a[i] nhất thoả mãn đk j<i 
    }// và mọi phần tử từ a[j] ->a[i] đều có giá trị <=a[i]

    a[n+1]= m + 1;
    for (int i=n; i>=1; --i) {
        int k= i + 1;
        while (a[k] <= a[i]) k= Next[k];

        Next[i]= k;// vị trí của phần tử xa a[i] nhất tmdk i<k và mọi 
    }// phần tử từ a[i] -> a[k] đều có giá trị <=a[i]
    // suy ra được a[i] sẽ là giá trị lớn nhất trong đoạn a[j]....a[i]....a[k]
    for (int i=1; i<=n; ++i) x[a[i]]= Next[i] - Pre[i] - 1;

    for (int i=1; i<=m; ++i) {
        if (!x[i]) s[i]= s[i-1];// số lượng phần tử nhiều nhất mà các giá trị<=i
        else s[i]= max (s[i-1], x[i]);
    }

    for (int i=1; i<=Q; ++i) printf ("%d\n", s[q[i]]);
}

int main ()
{
    if (fopen ("SEQ.inp", "r")) {
        freopen ("SEQ.inp", "r", stdin);
        freopen ("SEQ.out", "w", stdout);
    }

    scanf ("%d%d", &n, &Q);
    for (int i=1; i<=n; ++i) {
        scanf ("%d", a+i);

        tmp[++m]= a[i];
    }
    for (int i=1; i<=Q; ++i) {
        scanf ("%d", q+i);

        tmp[++m]= q[i];
    }

    sort (tmp+1, tmp+m+1);
    for (int i=1; i<=n; ++i) a[i]= lower_bound (tmp+1, tmp+m+1, a[i]) - tmp;
    for (int i=1; i<=Q; ++i) q[i]= lower_bound (tmp+1, tmp+m+1, q[i]) - tmp;

    if (n <= 1000 && Q <= 1000) sub1();
    else sub2();
}
