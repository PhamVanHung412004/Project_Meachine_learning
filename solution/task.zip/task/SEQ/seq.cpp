#include<bits/stdc++.h>
#define fi first
#define sc second
#define task "seq"
using namespace std;
const int maxn=1e5+7;
int n,q;
long long a[maxn],b[maxn],c[maxn],nex[maxn],pre[maxn];
typedef pair<long long,int> II;
II hoangdetung[maxn];
struct segment{
    vector<int> st;
    void init(int n){
        st.resize(4*n,0);
    }
    // ham thuc hien thay the
    void update(int u,int val,int r=1,int lo=1,int hi=n){
        if(lo==hi){
            st[r]=val;
            return ;
        }
        int mid=(lo+hi)/2;
        if(u<=mid){
            update(u,val,2*r,lo,mid);
        }
        else{
            update(u,val,2*r+1,mid+1,hi);
        }
        st[r]=max(st[2*r],st[2*r+1]);
    }
    // lay gia tri max
    int get(int u,int v,int r=1,int lo=1,int hi=n){
        if(v<lo||u>hi){
            return 0;// ko giao
        }
        if(u<=lo&&v>=hi){
            return st[r];//nam trong
        }
        int mid=(lo+hi)/2;
        int trai=get(u,v,2*r,lo,mid);
        int phai=get(u,v,2*r+1,mid+1,hi);
        return max(trai,phai);
    }
}tree;
void sub1(){
    for(int i=1;i<=q;i++){
        int ds=0,dem=0;
        for(int j=1;j<=n;j++){
            if(a[j]<=b[i]){
                dem++;
            }
            else{
                ds=max(ds,dem);
                dem=0;
            }
        }
        cout<<max(ds,dem)<<"\n";
    }
}
void sub2(){
    tree.init(n);
    a[0]=INT_MAX;
    a[n+1]=INT_MAX;
    for(int i=1;i<=n;i++){
        int j=i-1;
        while(a[j]<=a[i]){
            j=pre[j];
        }
        pre[i]=j;
    }
    for(int i=n;i>=1;i--){
        int j=i+1;
        while(a[j]<=a[i]){
            j=nex[j];
        }
        nex[i]=j;
    }
    for(int i=1;i<=n;i++){
        hoangdetung[i]={a[i],nex[i]-pre[i]-1};
    }
    sort(hoangdetung+1,hoangdetung+n+1);
    for(int i=1;i<=n;i++){
        c[i]=hoangdetung[i].fi;
        tree.update(i,hoangdetung[i].sc);
    }
    for(int i=1;i<=q;i++){
        int u=upper_bound(c+1,c+n+1,b[i])-c-1;
        cout<<tree.get(1,u)<<"\n";
    }
}
int main(){
if(fopen(task".inp","r")){
    freopen(task".inp","r",stdin);
    freopen(task".out","w",stdout);
}
ios::sync_with_stdio(false);
cin.tie(NULL);
cin>>n>>q;
for(int i=1;i<=n;i++){
    cin>>a[i];
}
for(int i=1;i<=q;i++){
    cin>>b[i];
}
if(n<=1000){
    sub1();
}
else{
    sub2();
}
return 0;
}
//6 4
//-2 5 6 10 -5 0
//-10
//5
//-4
//11
//-5 -2 0 5 6 10
