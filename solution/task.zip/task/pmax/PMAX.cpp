#include <bits/stdc++.h>
#define maxn 1001

using namespace std;

int m, n, a[maxn][maxn];
long long f[maxn][maxn];

int main() {
    freopen("pmax.inp","r",stdin);
    freopen("pmax.out","w",stdout);
    cin>>m>>n
    for(int i=1;i<=m;i++)
        for(int j=1;j<=n;j++) cin>>a[i][j];
    f[1][1]=a[1][1];
    for(int j=2;j<=n;j++)
    if (a[1][j]>0 && f[1][j-1]>0) f[1][j]=(f[1][j-1]+a[1][j]);
    else f[1][j]=0;
    for(int i=2;i<=m;i++)
    if (a[i][1]>0 && f[i-1][1]>0) f[i][1]=(f[i-1][1]+a[i][1]);
    else f[i][1]=0;
    for(int i=2;i<=m;i++)
    for(int j=2;j<=n;j++) {
        f[i][j]=0;
        if (a[i][j]>0) {
            if (f[i-1][j]>0) f[i][j]=f[i-1][j]+a[i][j];
            if (f[i][j-1]>0) f[i][j]=max(f[i][j],f[i][j-1]+a[i][j]);
        }
    }
    cout<<f[m][n];
}
